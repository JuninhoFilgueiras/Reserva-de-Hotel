/**
 * 
 */
/**
 * 
 */
module Paradigmas {
}